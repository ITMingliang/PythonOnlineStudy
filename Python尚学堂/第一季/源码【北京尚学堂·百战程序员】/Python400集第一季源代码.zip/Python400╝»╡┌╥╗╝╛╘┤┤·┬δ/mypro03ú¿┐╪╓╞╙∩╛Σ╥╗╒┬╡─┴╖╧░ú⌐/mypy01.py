b = []
if  not b:
    print("空的列表是false")

c = "False"    #非空字符串也是：True
if c:
    print("c")

d = 10
if d:
    print("d")

if 3<d<100:
    print("3<d<100")

# if 3<c and (c=20):  条件表达式不能使用“赋值操作符”
