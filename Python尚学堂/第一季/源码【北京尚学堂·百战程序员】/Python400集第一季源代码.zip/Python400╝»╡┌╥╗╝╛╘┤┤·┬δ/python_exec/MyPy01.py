print("a")
print("b")
print("c")
