print("aa",end="\n")
print("bb",end="\t")
print("cc")
