#coding=utf-8
#测试run to cursor运行到光标处

a = 10

while True:
    b = 3
    a = a+b
    print("step1")
    print(a)
    print("step2")
