#coding=utf-8

a = 10
while True:
    b = 3
    a = a+b
    print("step1")
    print(a)
    print("step2")
