#f = open(r"d:\a.txt","a")
f = open(r"a.txt","a")
f.write("itbaizhan\nsxt\n")
f.close()