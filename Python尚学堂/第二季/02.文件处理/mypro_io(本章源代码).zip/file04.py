with open(r"d.txt","a") as f:
    f.write("gaoqi,i love u!")
