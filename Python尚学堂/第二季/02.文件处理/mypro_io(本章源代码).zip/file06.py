with open("e.txt","r",encoding="utf-8") as f:
    for a in f:
        print(a,end="")