import os


#os.system("notepad.exe")
#os.system("ping www.baidu.com")
#os.system("cmd")


#直接调用可执行的文件
os.startfile(r"C:\Program Files (x86)\Tencent\WeChat\WeChat.exe")
