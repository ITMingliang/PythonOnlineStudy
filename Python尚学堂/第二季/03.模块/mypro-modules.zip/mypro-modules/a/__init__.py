import turtle
import math

print("导入a包")

__all__=["module_A","module_A2"]