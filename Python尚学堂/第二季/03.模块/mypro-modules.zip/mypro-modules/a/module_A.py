def fun_A():
    print("in fun_A")