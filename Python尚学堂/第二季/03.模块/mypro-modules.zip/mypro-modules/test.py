import Salary

#math.sin()
print(Salary.__doc__)
print(Salary.daySalary.__doc__)
print(Salary.__name__)

import baizhanSuperMath.demo1
baizhanSuperMath.demo1.add()