import math

print("in test02,模块被加载...")
import baizhanMath2.demo1
def t1():
    pass

