import test02
import test02

print("####")
import importlib
importlib.reload(test02)